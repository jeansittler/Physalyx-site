PHYSALIX SPECTRO — BOITIER V2.3 CORRIGE
Date : 19/10/2026

OBJECTIF
-------
Cette révision corrige les deux défauts constatés sur l'impression V2.1/V2.2 sans redessiner le boîtier.
La base reste la géométrie originale du Lycée Valin.

CORPS V2.3
-----------
1. Logement DEL
   - Le logement DEL est celui du corps original Lycée Valin.
   - Aucun ajout n'intersecte désormais cette zone.
   - La position et l'axe optique de la DEL restent donc ceux du montage original validé.

2. FH1X2
   - Les dimensions internes du berceau sont conservées car le FH1X2 réel y entre correctement.
   - Le berceau a été reculé de 10,8 mm par rapport à la V2.1.
   - Il n'affleure plus la DEL et laisse une longueur de pattes libre.
   - Un pied relie le berceau au plancher du boîtier afin qu'il reste mécaniquement solidaire malgré ce recul.

3. AS7341
   - Le passage latéral du câble Qwiic vers la breadboard / USB est conservé.
   - Le logement du capteur et le trajet optique ne sont pas déplacés.

COUVERCLE V2.3
--------------
La géométrie de référence est directement le couvercle original Lycée Valin afin de conserver :
- le pourtour de la cuve ;
- la flèche d'orientation ;
- les quatre perçages ;
- les rayons extérieurs ;
- l'emboîtement.

Correction importante :
- sur les V2/V2.2, la pièce ajoutée pour fermer l'ouverture LCD montait jusqu'à z = +0,10 mm alors que la face originale est à z = 0 ;
- cette surépaisseur pouvait rendre visible la zone rebouchée et dégrader l'aspect de la face supérieure ;
- sur la V2.3, le rebouchage affleure exactement à z = 0, sans aucune surépaisseur.

Gravure conservée :
    Physalix
    Spectro

Elle est sur deux lignes, centrée côté USB, et lisible lorsque l'ouverture de cuve est placée vers l'utilisateur.
Profondeur nominale de gravure : 0,45 mm.

FICHIERS A IMPRIMER
-------------------
- Physalix_Spectro_V2_3_Corps.3mf
- Physalix_Spectro_V2_3_Couvercle.3mf

Les STL correspondants sont fournis également.
Les sources OpenSCAD sont fournies pour traçabilité.

VERIFICATIONS GEOMETRIQUES
--------------------------
Corps : 100 x 100 x 39 mm
Couvercle : 100 x 100 x 8 mm
Les deux maillages STL/3MF sont fermés (watertight) et constitués d'une seule composante.

CONSEILS POUR LE PREMIER TIRAGE
-------------------------------
- PLA noir opaque.
- Couche 0,20 mm.
- Conserver l'orientation d'impression utilisée pour le boîtier original si possible.
- Aucun support dans le trajet optique.
- Aucun support dans le passage câble AS7341.
- Pour obtenir une face supérieure aussi propre que possible : suffisamment de couches supérieures et, si disponible dans le profil de l'imprimante, finition/ironing de la dernière couche.

AVANT UNE SERIE DE 10
---------------------
Imprimer un seul exemplaire V2.3 et vérifier physiquement :
1. insertion de l'ancienne DEL puis de la nouvelle DEL 5 mm ;
2. alignement optique ;
3. insertion du FH1X2 dans son berceau et longueur disponible des pattes ;
4. passage naturel du câble AS7341 ;
5. fermeture et quatre vis ;
6. aspect de la face supérieure du couvercle.

Ne lancer la série qu'après ces six contrôles.
