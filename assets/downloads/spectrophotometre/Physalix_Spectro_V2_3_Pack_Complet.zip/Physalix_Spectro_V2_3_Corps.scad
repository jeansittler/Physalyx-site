$fn=96;

// Physalix Spectro V2.3 — corps
// Base : géométrie ORIGINALE Lycée Valin, non modifiée autour de la DEL.
// Retouches uniquement :
// 1) encoche latérale AS7341 vers breadboard/USB ;
// 2) berceau FH1X2 reculé d'environ 11 mm par rapport à la V2.1.

module rounded_slot_x(cx, cy, cz, depth, w, h, r){
    hull(){
        for (sy=[-1,1]) for (sz=[-1,1])
            translate([cx-depth/2,
                       cy + sy*(w/2-r),
                       cz + sz*(h/2-r)])
                rotate([0,90,0]) cylinder(h=depth, r=r, center=false);
    }
}

module fh1x2_cradle_recul(){
    // Dimensions internes IDENTIQUES à la V2.1, car le FH1X2 imprimé
    // s'y emboîte correctement. Seule sa position est reculée.
    cx = -28.75;       // alignement des pattes de DEL conservé
    y_front = 27.0;    // V2.1 = 16.2 : recul de 10.8 mm
    zc = 15.0;         // axe vertical inchangé

    inner_w = 5.70;
    inner_h = 3.15;
    length = 9.60;
    wall = 1.30;
    floor = 1.25;

    x0 = cx-(inner_w/2+wall);
    total_w = inner_w+2*wall;
    z_floor = zc-inner_h/2-floor;

    // Pied relié au plancher intérieur (z ~2 mm), pour que le berceau
    // reste mécaniquement solidaire malgré son recul.
    translate([x0, y_front, 2.0])
        cube([total_w, length, z_floor-2.0]);

    // Semelle du connecteur.
    translate([x0, y_front, z_floor])
        cube([total_w, length, floor]);

    // Deux joues latérales de maintien.
    translate([x0, y_front, z_floor])
        cube([wall, length, inner_h+floor+0.8]);
    translate([cx+inner_w/2, y_front, z_floor])
        cube([wall, length, inner_h+floor+0.8]);

    // Butée arrière basse : maintien longitudinal sans bloquer les fils.
    translate([cx-inner_w/2, y_front+length-1.0, z_floor])
        cube([inner_w, 1.0, floor+0.9]);
}

difference(){
    union(){
        // IMPORTANT : corps original, donc logement DEL strictement restauré.
        import("Physalix_Spectro_V2_BASE_Corps_LyceeValin.stl", convexity=40);
        fh1x2_cradle_recul();
    }

    // Passage câble AS7341 latéral vers la breadboard / USB.
    // Géométrie optique et logement du capteur inchangés.
    rounded_slot_x(-9.2, -20.5, 34.4, 7.2, 10.0, 11.8, 2.4);
}
