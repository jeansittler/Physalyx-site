$fn=96;

// Physalix Spectro V2.3 — couvercle
// Base : couvercle ORIGINAL Lycée Valin pour conserver exactement :
// - le pourtour de cuve ;
// - la flèche ;
// - les 4 perçages ;
// - les rayons et l'emboîtement.
//
// Correction majeure par rapport aux V2/V2.2 :
// la plaque qui bouche l'ancien LCD affleure EXACTEMENT à z=0.
// L'ancienne V2 montait à z=+0,10 mm, créant une surépaisseur visible.

difference(){
    union(){
        import("Physalix_Spectro_V2_BASE_Couvercle_LyceeValin.stl", convexity=40);

        // Fermeture LCD avec léger recouvrement latéral pour une union robuste,
        // mais surface supérieure strictement coplanaire avec l'original (z=0).
        translate([10.25,-36.05,-3.20])
            cube([25.12,72.10,3.20]);
    }

    // Gravure en creux : deux lignes, côté USB, lisible cuve vers l'utilisateur.
    // Profondeur 0,45 mm, suffisante pour être lisible sans fragiliser la face.
    translate([28.0, 0.0, -0.45])
        rotate([0,0,-90])
            linear_extrude(height=0.50)
                text("Physalix",
                     size=6.2,
                     font="DejaVu Sans:style=Bold",
                     halign="center",
                     valign="center",
                     spacing=1.0);

    translate([19.5, 0.0, -0.45])
        rotate([0,0,-90])
            linear_extrude(height=0.50)
                text("Spectro",
                     size=5.2,
                     font="DejaVu Sans:style=Bold",
                     halign="center",
                     valign="center",
                     spacing=1.0);
}
